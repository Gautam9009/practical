package methods;

public class Defaultcon {
	Defaultcon(){
		System.out.println("Default constructor is created");
	}
	public static void main(String[] args) {
		Defaultcon Defaultcon=new Defaultcon();
	}
}
