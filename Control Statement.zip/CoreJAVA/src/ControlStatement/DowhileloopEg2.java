package ControlStatement;

public class DowhileloopEg2 {
public static void main(String[] args) {
	int i = 0;
	System.out.println("First 10 even number \n");
	do {
		System.out.println(i);  // ststement
		i = i + 2;  //  increment
	}while(i<=10);  // condition
}
}
