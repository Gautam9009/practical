package ControlStatement;

public class ForEachArr1 {
	public static void main(String[] args) {
		// declare an array
		int arr[]= {12,15,23,25,28,42,32};
		// using for each loop for print the array
		for(int i:arr) {
			System.out.println(i);
		}
		System.out.println("chalte raho");
	}
}
