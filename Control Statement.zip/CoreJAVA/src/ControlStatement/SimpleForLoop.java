package ControlStatement;

public class SimpleForLoop {
public static void main(String[] args) {
	for(int i = 1; i<=10; i++) {
		for(int j = 10; j<=20; j++) {
			System.out.println("The outpout is " + " "+j);
		}
		System.out.println();
	}
}
}
