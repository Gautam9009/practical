package ControlStatement;

public class DowhileloopEg3 {
	public static void main(String[] args) {
		int i = 1;
		System.out.println("First 10 odd number \n");
		do {
			System.out.println(i);  // statement
			i = i + 2;  //  increment
		}while(i<=20);  // condition
	}
}
