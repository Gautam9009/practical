package ControlStatement;

public class SwitchEg {
public static void main(String[] args) {
	int no1=10;
	switch(no1) {
	case 1:
		System.out.println("10");
		break;
		
	case 2:
		System.out.println("20");
		break;
		
	case 3:
		System.out.println("30");
		break;
		
	case 4:
		System.out.println("40");
		break;
		
	case 5:
		System.out.println("50");
		break;
		
		default:System.out.println("Invalid Statement");
}
}
}