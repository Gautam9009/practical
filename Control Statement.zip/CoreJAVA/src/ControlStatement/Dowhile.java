package ControlStatement;

public class Dowhile {
public static void main(String[] args) {
	int i = 1;
	do {
		System.out.println(i);  // statement
		i++;
	}while(i<=10);  // condition
}
}
