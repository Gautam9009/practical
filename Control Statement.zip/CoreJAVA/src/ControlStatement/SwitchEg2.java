package ControlStatement;

public class SwitchEg2 {
public static void main(String[] args) {
	char ch='a';
	switch(ch) {
	case 'p':
		System.out.println("first code execute");
		break;
		
	case 'q':
		System.out.println("first code execute");
		break;
		
	case 'r':
		System.out.println("first code execute");
		break;
		
	case 's':
		System.out.println("first code execute");
		break;
		
		default:System.out.println("invalid");
	}
}
}
